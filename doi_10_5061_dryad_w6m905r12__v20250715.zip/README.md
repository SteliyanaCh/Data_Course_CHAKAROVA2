# Cell-specific protein expression in Alzheimer's disease prefrontal cortex

**Dataset DOI:**
[https://doi.org/10.5061/dryad.w6m905r12](https://doi.org/10.5061/dryad.w6m905r12)

#### GENERAL INFORMATION

**1. Study Objective:**
This dataset supports a spatial proteomics study investigating cell-specific alterations in protein expression within the prefrontal cortex (Brodmann area 8/9) in Alzheimer's disease (AD). The analysis aims to characterize how protein signatures differ between AD and control samples at the cellular level, focusing on neurons, astrocytes, and microglia.

**2.Authors Information:**

* Principal Investigator Contact Information

Name: Mohammad Haeri, MD PhD

```
 Institution: University Of Kansas Medical Center
 Email: mhaeri@kumc.edu
```

* First Author Contact Information

  ```
   Name: Maryam Gholampour, PharmD
   Institution: University Of Kansas Medical Center
   Email: mgholampour@kumc.edu
  ```

**3. Data Collection Dates:** 2022-2023 

**4. Geographic Location:**
Postmortem human brain tissue obtained from the University of Kansas Alzheimer's Disease Research Center (KU ADRC) Neuropathology Core.

**5. Funding Information:**
National Institutes of Health Grant Number: P30 AG072973

#### SHARING / ACCESS INFORMATION

**1. License:**
CC0 1.0 Universal (CC0 1.0) Public Domain Dedication

**2. Associated Publications:**
Gholampour M, Basu MK, Swerdlow RH, Zhuo X, Haeri M. Cell-specific protein expression in Alzheimer's disease prefrontal cortex. Alzheimer's Dement. 2025; 21:e70339. [https://doi.org/10.1002/alz.70339](https://doi.org/10.1002/alz.70339)

**3. Public Repository Hosting the Data:**
Dryad Digital Repository

#### DATA & FILE OVERVIEW

**File:** `Initial_Dataset_Protein.xlsx`
**Description:**
This Excel file contains raw and processed protein expression data derived from the GeoMx Digital Spatial Profiler (NanoString Technologies) platform. Data represent spatially resolved proteomic profiles from formalin-fixed paraffin-embedded (FFPE) sections of human prefrontal cortex.

**Total Number of Variables:** 77 (including sample IDs and 76 protein measurements)
**Number of Samples/ROIs:** 8
**Experimental Groups:**

* **Control samples:** R001, R002, R003, R004
* **AD samples:** R005, R006, R007, R008

  #### EXPERIMENTAL DESIGN & METHODS

  **Tissue Source and Region:**
  Prefrontal cortex (Brodmann area 8/9) FFPE tissue from 4 AD patients and 4 age-matched non-demented controls.

  **Spatial Proteomics Technique:**
  GeoMx Digital Spatial Profiler was used to analyze spatially defined 660 × 785 µm regions of interest (ROIs). ROIs were selected based on immunofluorescent staining with cell-type-specific markers:
  * Neurons: NeuN
  * Microglia: Iba-1
  * Astrocytes: GFAP
  * Nuclear staining: SYTO 83

  **Protein Detection Method:**
  A panel of 76 oligonucleotide-tagged antibodies was used. After ROI definition and UV-mediated tag release, oligo barcodes were hybridized and quantified using the NanoString nCounter system.

  **Data Processing:**
  * Protein counts were normalized using ERCC spike-in controls.
  * Signal was adjusted using signal-to-noise ratios to correct for background.
  * Data were log2-transformed for downstream analyses.



## Human subjects data

The Kansas University Medical Center Human Subjects Committee (KUMC HSC) issued approval for all involvement of human subjects, and all participants provided informed consent prior to enrollment. This investigation was conducted in accordance with the Code of Ethics set forth by the World Medical Association (the Declaration of Helsinki).